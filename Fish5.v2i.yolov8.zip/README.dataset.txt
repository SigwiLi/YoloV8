# Fish5 > 2025-05-22 6:41pm
https://universe.roboflow.com/siqi-li/fish5-mamys

Provided by a Roboflow user
License: CC BY 4.0

