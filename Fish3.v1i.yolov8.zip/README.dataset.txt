# Fish3 > 2024-07-03 12:26am
https://universe.roboflow.com/siqi-li/fish3-tciyq

Provided by a Roboflow user
License: CC BY 4.0

